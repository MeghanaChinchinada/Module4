package stepDefinitions;

import org.openqa.selenium.WebDriver;


import Elementlocators.ElementLocators;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelStepDefinition {

	WebDriver driver = null;
	@Given("^The User is on Hotel Booking Application Home page$")
	public void the_User_is_on_Hotel_Booking_Application_Home_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		
		PageFactPack.PageFactory.openbrowser("file:///C:/Users/mchinchi/Desktop/cucumber/Hotel%20booking%20case%20study/login.html");
	}

	@When("^User enters User Name$")
	public void user_enters_User_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.UserName, "capgemini");
	}

	@When("^Enters the Password$")
	public void enters_the_Password() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Password, "capg1234");
	}

	@Then("^User is successfully logged in$")
	public void user_is_successfully_logged_in() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.clickmethod(ElementLocators.Login);
	}

	@Given("^The User is on Hotel Booking Application Booking page$")
	public void the_User_is_on_Hotel_Booking_Application_Booking_page() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//PageFactPack.PageFactory.openbrowser("file:///C:/Users/mchinchi/Desktop/cucumber/Hotel%20booking%20case%20study/hotelbooking.html");
	}

	@When("^User Enters First Name$")
	public void user_Enters_First_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
	    PageFactPack.PageFactory.SendValue(ElementLocators.FirstName, "Abhinav");
	}

	@When("^Enters Last Name$")
	public void enters_Last_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.LastName, "Mithra");
	}

	@When("^Enters Email$")
	public void enters_Email() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Email, "abhinav000@gmail.com");
	}

	@When("^Enters Mobile no$")
	public void enters_Mobile_no() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Mobileno, "7589476563");
	}

	@When("^Enters Address$")
	public void enters_Address() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Address,"d.no:1-2-32,Golden road");
	}

	@When("^Select City$")
	public void select_City() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.City,"Chennai");
	}

	@When("^Select State$")
	public void select_State() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.State,"TamilNadu");
	}

	@When("^Select Number of guest staying$")
	public void select_Number_of_guest_staying() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Numberofgueststaying,"3");
	}

	@When("^Enters Card Holder Name$")
	public void enters_Card_Holder_Name() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.CardHolderName,"Abhinav Mishra");
	}

	@When("^Enters Debit Card Number$")
	public void enters_Debit_Card_Number() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.DebitCardNumber,"IND765437635");
	}

	@When("^Enters CVV$")
	public void enters_CVV() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.CVV,"10099384");
	}

	@When("^Enters Expiration month$")
	public void enters_Expiration_month() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Expirationmonth,"October");
	}

	@When("^Enters Expiration Year$")
	public void enters_Expiration_Year() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.SendValue(ElementLocators.Expirationyear,"2025");
	}

	@When("^Click Confirm Booking button$")
	public void click_Confirm_Booking_button() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.clickmethod(ElementLocators.Confirm);
	}

	@Then("^User is successfully confirmed booking$")
	public void user_is_successfully_confirmed_booking() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		//PageFactPack.PageFactory.openbrowser("file:///C:/Users/mchinchi/Desktop/cucumber/Hotel%20booking%20case%20study/success.html");
	}

	@Then("^Browser is closed$")
	public void browser_is_closed() throws Throwable {
	    // Write code here that turns the phrase above into concrete actions
		PageFactPack.PageFactory.close();
	}


}
