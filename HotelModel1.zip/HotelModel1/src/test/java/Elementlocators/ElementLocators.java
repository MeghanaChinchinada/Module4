package Elementlocators;

import org.openqa.selenium.By;

public class ElementLocators {

	public static By UserName=By.xpath("//input[@name='userName']");
	public static By Password=By.xpath("//input[@name='userPwd']");
	public static By Login=By.xpath("//input[@class='btn']");
	
	
	public static By FirstName=By.xpath("//input[@name='txtFN']");
	public static By LastName=By.xpath("//input[@name='txtLN']");
	public static By Email=By.xpath("//input[@name='Email']");
	public static By Mobileno=By.xpath("//input[@name='Phone']");
	public static By Address=By.xpath("//textarea[@name='address']");
	public static By City=By.xpath("//select[@name='city']");
	public static By State=By.xpath("//select[@name='state']");
	public static By Numberofgueststaying=By.xpath("//select[@name='persons']");
	public static By Noofroomsbooked=By.xpath("//div[@id='rooms']");
	public static By CardHolderName=By.xpath("//input[@id='txtCardholderName']");
	public static By DebitCardNumber=By.xpath("//input[@name='debit']");
	public static By CVV=By.xpath("//input[@name='cvv']");
	public static By Expirationmonth=By.xpath("//input[@name='month']");
	public static By Expirationyear=By.xpath("//input[@name='year']");
	public static By Confirm=By.xpath("//input[@id='btnPayment']");
			
}


