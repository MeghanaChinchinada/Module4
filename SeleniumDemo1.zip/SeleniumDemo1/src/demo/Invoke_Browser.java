package demo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Invoke_Browser {

	public static void main(String[] args) throws InterruptedException {
		
		System.setProperty("webdriver.chrome.driver", "C:/selenium/chromedriver.exe");
		WebDriver driver=new ChromeDriver();
		
//		driver.get("https://www.capgemini.com");
//		String title=driver.getTitle();
//		System.out.println(title);
//		        //OR
//		driver.navigate().to("https://www.capgemini.com");
//		driver.findElement(By.linkText("Industries")).click();
//		String title2=driver.getCurrentUrl();
//		System.out.println(title2);
//		Thread.sleep(3000);
//		driver.navigate().back();
//		
//		driver.navigate().to("https://www.google.com");
//		driver.findElement(By.linkText("Gmail")).click();
//		String title1=driver.getTitle();
//		System.out.println(title1);
		//driver.findElement(By.id("#gb_07"));
		

		
//		driver.navigate().to("https://www.google.com");
//		String title1=driver.getTitle();
//		driver.findElement(By.name("q")).sendKeys("Capgemini");
//		Thread.sleep(3000);
		
		
		                          //Application
		 
		driver.navigate().to("http://demowebshop.tricentis.com");
//		driver.findElement(By.linkText("Register")).click();
//		driver.findElement(By.id("gender-female")).click();
//		driver.findElement(By.name("FirstName")).sendKeys("Remo");
//		driver.findElement(By.name("LastName")).sendKeys("Mar");
//		driver.findElement(By.name("Email")).sendKeys("remo0000@gmail.com");
//		driver.findElement(By.name("Password")).sendKeys("xyz@123");
//		driver.findElement(By.name("ConfirmPassword")).sendKeys("xyz@123");
//		driver.findElement(By.id("register-button")).click();
		
		driver.findElement(By.linkText("Log in")).click();
		driver.findElement(By.name("Email")).sendKeys("remo0000@gmail.com");
		driver.findElement(By.name("Password")).sendKeys("xyz@123");
		driver.findElement(By.name("RememberMe")).click();
		driver.findElement(By.xpath("//input[@value='Log in']")).click();
		
		//driver.findElement(By.className("ico-logout")).click();
		
		driver.findElement(By.linkText("Log out")).click();
		
		
	}
	
}
